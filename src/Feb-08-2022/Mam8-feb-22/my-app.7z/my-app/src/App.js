
import './App.css';
import ReduxComponentEx1 from './components/ReduxComponentEx1';






function App(){
  return <div>
    {/* <PropsExample num1="564"/>
    <JSXDemoC num1="5" num2="10" op="+"/>
    <CharCountF>This is a wonderful morning</CharCountF>
    <InputExC></InputExC> */}
    <p>4th of Feb(mannually written by me)</p>
    {/* <UpperCase></UpperCase>
    <DateComponent></DateComponent> */}
    {/* <BlogPage></BlogPage>
    
     <HttpExample></HttpExample> */}

   
    {/* <BlogPage></BlogPage> */}
    <ReduxComponentEx1></ReduxComponentEx1>
    
   

  </div>
  

}

export default App;
